package com.example.ass_mystockwatch;

import android.net.Uri;

import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class StockDownloader implements Runnable {
    private final String data;
    private final String data2;
    private MainActivity mainActivity;

    // My API KEY = pk_245cca82bab94c7b810ff14f707af946
    private final String Url1 = "https://cloud.iexapis.com/stable/stock/";
    private final String Url2 = "/quote?token=pk_b727dd78c52b4714bb326f06f34e5186 ";
    private ArrayList<String> offlineContent = new ArrayList<>();
    private static final String TAG = "StockDownloader";

    // Constructor to get reference of MainActivity
    public StockDownloader(MainActivity mainActivity, String data, String data2) {
        this.mainActivity = mainActivity;
        this.data=data;
        this.data2=data2;
    }



    protected Stock parseJSON(String s){ //parse json string and convert to Stock Object
        try{

            JSONObject jFinance = new JSONObject(s);
            String symbol = jFinance.getString("symbol");
            String name = jFinance.getString("companyName");

            String latest = jFinance.getString("latestPrice");
            double latestPrice = 0.0;
            if (latest != null && !latest.trim().isEmpty() && !latest.trim().equals("null")){
                latestPrice = Double.parseDouble(latest.trim());
            }


            String ch = jFinance.getString("change");
            double change = 0.0;
            if (ch != null && !ch.trim().isEmpty() && !ch.trim().equals("null")){
                change = Double.parseDouble(ch.trim());
            }


            String chP = jFinance.getString("changePercent");
            double changePercent = 0.0;
            if (chP != null && !chP.trim().isEmpty() && !chP.trim().equals("null")){
                changePercent = Double.parseDouble(chP.trim());
            }

            Stock stock = new Stock(symbol, name, latestPrice, change, changePercent);
            return stock;

        }catch (Exception e) {
            Log.d(TAG, "parseJSON: error");
        }
        return null;
    }

    @Override
    public void run() {

        offlineContent.add(data);
        if(data2!=null){
            offlineContent.add(data2);
        }

        Uri dataUri = Uri.parse(Url1 + data + Url2);
        String urlToUse = dataUri.toString();
        StringBuilder sb = new StringBuilder();

        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            conn.connect();
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                Log.d(TAG, "run: HTTP ResponseCode NOT OK: " + conn.getResponseCode());
                handleResults(null);
                return;
            }
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "handleResults: Failure in data download hitanshu");
            handleResults(null);
            return;
        }
        Log.d(TAG, "getURLData: "+sb.toString() );
        handleResults(sb.toString());
    }


    public void handleResults(final String s) {
        if (s != null) {
            final Stock stock = parseJSON(s);
            mainActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mainActivity.updateFinanceData(stock);
                }
            });

        } else {
            if (offlineContent.size() == 2) {
                final Stock stock;
                stock = new Stock(offlineContent.get(0), offlineContent.get(1), 0, 0, 0);
                mainActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mainActivity.updateFinanceData(stock);
                    }
                });

            }
        }
    }
}
