package com.example.ass_mystockwatch;

import android.net.Uri;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

// this class is for Runnable Task
public class NameDownloader implements Runnable {
    private static final String TAG = "NameDownloader";
    private MainActivity mainActivity;
    //link of share market symbol and name of company
    private final String stocksymbolUrl = "https://api.iextrading.com/1.0/ref-data/symbols";
    private HashMap<String, String> symbolnameHashMap = new HashMap<String, String>();

    //constructor to get reference of MainActivity
    public NameDownloader(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    private HashMap<String, String> parseUrlJsonString(String s) {
        try{
            JSONArray jObjMain = new JSONArray(s);
            for (int i = 0; i < jObjMain.length(); i++){
                JSONObject jsonS = (JSONObject) jObjMain.get(i);
                String symbol = jsonS.getString("symbol");
                String name = jsonS.getString("name");
                symbolnameHashMap.put(symbol, name);
            }
            return symbolnameHashMap;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void run() {

        Uri getData = Uri.parse(stocksymbolUrl); // parse Url to get perfect string if in case of space %20
        String urlLink = getData.toString();


        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlLink);
            Log.d(TAG, "URL:"+url);
            // get connection and set Get method on top of it
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                Log.d(TAG, "run: HTTP ResponseCode NOT OK: " + conn.getResponseCode());
                handleResults(null);
                return;
            }

            // get input stream
            InputStream inputS = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(inputS)));
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "run: Failure in data download");
            handleResults(null);
            return;
        }
        Log.d(TAG, "getURLData: "+sb.toString() );
        handleResults(sb.toString());


    }
    public void handleResults(final String jsonString) {
        if (jsonString == null) {
            Log.d(TAG, "handleResults: Failure in data download");
            return;
        }

        final HashMap<String, String> symbnameMap = parseUrlJsonString(jsonString);

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mainActivity.updateData(symbnameMap);
            }
        });
    }
}

